# MTN DiceRoll
a simple game of dice rolling 
edit/add 2 category and roll  